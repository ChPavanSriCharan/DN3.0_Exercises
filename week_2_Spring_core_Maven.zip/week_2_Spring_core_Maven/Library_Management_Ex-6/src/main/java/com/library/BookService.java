package com.library;

import org.springframework.stereotype.Service;

@Service
public class BookService {
    private final BookRepository bookRepository;

    // Constructor-based dependency injection (preferred)
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    // Getter for bookRepository (if needed)
    public BookRepository getBookRepository() {
        return bookRepository;
    }

    // Method to indicate successful configuration
    public void performService() {
        // Implement service logic here
        System.out.println("Successfully Ran the LibraryManagementApplication main class to verify the annotation-based configuration.");
    }
}
