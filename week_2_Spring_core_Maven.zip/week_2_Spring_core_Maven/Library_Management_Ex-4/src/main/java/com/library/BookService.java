package com.library;

import com.library.BookRepository;

public class BookService {
    private BookRepository bookRepository;

    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
    }

    public void performService() {
        // Implement service logic here
        System.out.println("Configured the Maven Compiler Plugin for Java version 1.8 in the pom.xml file");
    }
}
